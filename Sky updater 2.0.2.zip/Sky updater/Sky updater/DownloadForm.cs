﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net;
using System.IO;
using Microsoft.Win32;

namespace Sky_updater
{
    internal partial class DownloadForm : Form
    {
        private bool FormCache = false;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private WebClient wc = new WebClient();
        private Timer timer3;
        private int nbUpdate = 0;
        private int Element = 0;
        private int NbElement = 0;
        private string NameFile;
        private List<string> APP;
        private string Chemin;
        private StreamReader reader1;
        private bool DownloadLibVLC = false;
        private string LibVLCVersion;
        private bool DownloadFrameworke = false;
        private bool ConnectionLost = false;
        //private int ProgressPercentage = 0;
        //private long TotalBytesToReceive = 0;
        // private long BytesReceived = 0;

        internal DownloadForm()
        {
            InitializeComponent();

            this.Opacity = 0;
            timer1.Enabled = true;
            timer2.Start();

            timer3 = new Timer(this.components);
            timer3.Interval = 2000;
            timer3.Tick += new EventHandler(Timer3_Tick);
            timer3.Enabled = true;

            wc.DownloadProgressChanged += new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged);
            wc.DownloadFileCompleted += new AsyncCompletedEventHandler(wc_DownloadFileCompleted);
        }

        private void Timer3_Tick(object sender, EventArgs e)
        {
            try
            {
                StreamReader reader = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/Sky updater r.ini"));
                string TestTexte = reader.ReadToEnd();
                reader.Close();
                reader = null;
                TestTexte = string.Empty;
                TestTexte = null;

                if (ConnectionLost == true)
                {
                    timer3.Enabled = false;
                    wc.CancelAsync();
                    wc.Dispose();
                    MessageBox.Show("Une erreur est survenue nous allons recommencer la mise à jour.", "Sky updater", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    if (File.Exists(Application.StartupPath + "Sky installer.exe"))
                    {
                        File.Delete(Application.StartupPath + "Sky installer.exe");
                    }
                    nbUpdate = 0;
                    timer2.Start();
                    timer3.Enabled = true;
                }

                ConnectionLost = false;
            }
            catch
            {
                ConnectionLost = true;
            }
        }

        private void wc_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            //BytesReceived = e.BytesReceived;
            //TotalBytesToReceive = e.TotalBytesToReceive;
            //ProgressPercentage = e.ProgressPercentage;
            progressBar1.Value = e.ProgressPercentage;
            label1.Text = "Progression de la mise à jour : " + EspaceNombre(e.BytesReceived / 1000) + " ko/" + EspaceNombre(e.TotalBytesToReceive / 1000) + " ko";
        }

        private void wc_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            if (e.Cancelled == false)
            {
                if (Element < NbElement)
                {
                    Element++;
                    string url = reader1.ReadLine();
                    NameFile = NameFileURL(url);
                    if (NameFile == "Sky updater.exe" || NameFile == "Sky updater.dll")
                    {
                        wc.DownloadFileAsync(new Uri(url), Chemin + @"\Série Sky\Install\" + NameFile);
                    }
                    else
                    {
                        wc.DownloadFileAsync(new Uri(url), Chemin + @"\Série Sky\" + NameFile);
                    }
                    return;
                }

                if (DownloadLibVLC && Element >= NbElement && Sky_updater.Update.CheckLibVLC(ref LibVLCVersion))
                {
                    if (File.Exists(Chemin + @"\Série Sky\libvlc.zip"))
                    {
                        if (Directory.Exists(Chemin + @"\Série Sky\libvlc"))
                        {
                            Directory.Delete(Chemin + @"\Série Sky\libvlc", true);
                        }
                        System.IO.Compression.ZipFile.ExtractToDirectory(Chemin + @"\Série Sky\libvlc.zip", Chemin + @"\Série Sky\libvlc");
                        System.IO.File.Delete(Chemin + @"\Série Sky\libvlc.zip");

                        Element++;
                        if (Element >= NbElement && nbUpdate < APP.Count())
                        {
                            AppDownload(APP[nbUpdate]);
                            nbUpdate++;
                        }
                        else if (Element >= NbElement && nbUpdate >= APP.Count())
                        {
                            timer3.Enabled = false;
                            wc.CancelAsync();
                            wc.Dispose();
                            foreach (string i in APP)
                            {
                                if (i != "Framework" && i != "Sky updater")
                                {
                                    RegistryKey classesKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);

                                    StreamReader reader = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/" + i + " r.ini"));
                                    string Version = reader.ReadLine();
                                    reader.Close();

                                    classesKey.CreateSubKey(i + " 2").SetValue("DisplayVersion", Version);
                                }
                            }

                            if (DownloadFrameworke == true)
                            {
                                Process process = new Process();
                                process.StartInfo.UseShellExecute = true;
                                process.StartInfo.FileName = Application.StartupPath + "Sky installer.exe";
                                process.Start();
                                process.Close();
                                process = null;
                            }

                            timer1.Enabled = true;
                        }
                        return;
                    }

                    NameFile = "libvlc.zip";
                    wc.DownloadFileAsync(new Uri("https://serie-sky.netlify.app/Download/App/Sky multi/libvlc.zip"), Chemin + @"\Série Sky\libvlc.zip");
                    return;
                }

                if (Element >= NbElement && nbUpdate < APP.Count())
                {
                    AppDownload(APP[nbUpdate]);
                    nbUpdate++;
                }
                else if (Element >= NbElement && nbUpdate >= APP.Count())
                {
                    timer3.Enabled = false;
                    wc.CancelAsync();
                    wc.Dispose();
                    foreach (string i in APP)
                    {
                        if (i != "Framework" && i != "Sky updater")
                        {
                            RegistryKey classesKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", true);

                            StreamReader reader = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/" + i + " r.ini"));
                            string Version = reader.ReadLine();
                            reader.Close();

                            classesKey.CreateSubKey(i + " 2").SetValue("DisplayVersion", Version);
                        }
                    }

                    if (DownloadFrameworke == true)
                    {
                        Process process = new Process();
                        process.StartInfo.UseShellExecute = true;
                        process.StartInfo.FileName = Application.StartupPath + "Sky installer.exe";
                        process.Start();
                        process.Close();
                        process = null;
                    }

                    timer1.Enabled = true;
                }
            }
        }

        private string SerieSkyIsPresent()
        {
            string App = "Sky multi 2";

            for (sbyte index = 0; index <= 4; index++)
            {
                switch (index)
                {
                    case 1:
                        App = "Sky picture 2";
                        break;

                    case 2:
                        App = "Sky note 2";
                        break;

                    case 3:
                        App = "Sky diary 2";
                        break;

                    case 4:
                        App = "Sky encrypt 2";
                        break;
                }

                RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\" + App);
                if (key != null)
                {
                    object o = key.GetValue("InstallLocation");

                    if (o != null)
                    {
                        if (System.IO.File.Exists(o.ToString() + "Sky updater.exe") && System.IO.File.Exists(o.ToString() + "mscorrc.dll"))
                        {
                            return o.ToString();
                        }
                    }
                }
            }

            return null;
        }

        private void AppDownload(string App)
        {
            string Path = System.IO.Path.GetDirectoryName(SerieSkyIsPresent());
            Path = System.IO.Path.GetDirectoryName(Path);

            switch (App)
            {
                case "Sky multi":
                    DownloadSky_multi(Path);
                    break;

                case "Sky picture":
                    DownloadSky_picture(ref Path);
                    break;

                case "Sky note":
                    DownloadSky_note(ref Path);
                    break;

                case "Sky diary":
                    DownloadSky_diary(ref Path);
                    break;

                case "Sky encrypt":
                    DownloadSky_encrypt(ref Path);
                    break;

                case "Framework":
                    DownloadFramework(ref Path);
                    break;

                case "Sky updater":
                    DownloadSky_updater(ref Path);
                    break;
            }
        }

        private void DownloadSky_multi(string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20multi/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;
            DownloadLibVLC = true;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;            
        }

        private void DownloadSky_picture(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20picture/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadSky_note(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20note/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadSky_diary(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20diary/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadSky_encrypt(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/App/Sky%20encrypt/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);

            Element++;
        }

        private void DownloadSky_updater(ref string Emplacement)
        {
            reader1 = new StreamReader(wc.OpenRead("https://serie-sky.netlify.app/Download/Sky%20updater/FileDownload.txt"));

            NbElement = Convert.ToInt32(reader1.ReadLine());
            Element = 0;

            string url = reader1.ReadLine();
            NameFile = NameFileURL(url);
            Chemin = Emplacement;
            DownloadFrameworke = true;
            if (NameFile == "Sky installer.exe")
            {
                wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\" + NameFile);
            }
            else
            {
                wc.DownloadFileAsync(new Uri(url), Emplacement + @"\Série Sky\Install\" + NameFile);
            }

            Element++;
        }

        private void DownloadFramework(ref string Emplacement)
        {
            NameFile = "Framework.zip";
            DownloadFrameworke = true;
            wc.DownloadFileAsync(new Uri("https://serie-sky.netlify.app/Download/Framework.zip"), Emplacement + @"\Série Sky\Framework.zip");
        }

        private string NameFileURL(string chaine)
        {
            string chaineReturn = string.Empty;

            foreach (char i in chaine.Reverse())
            {
                if (i == '/')
                {
                    break;
                }

                chaineReturn += i;
            }

            chaine = string.Empty;

            foreach (char i in chaineReturn.Reverse())
            {
                chaine += i;
            }

            return chaine;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    Environment.Exit(0);
                }
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                FormDeplace = false;
            }
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.LinkVisited = true;
            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.FileName = "https://serie-sky.netlify.app/index.html";
            process.Start();
            process.Close();
            process = null;
        }

        private string EspaceNombre(double element)
        {
            string elementString = element.ToString();
            List<char> chaineString = new List<char>();

            foreach (char i in elementString)
            {
                chaineString.Add(i);
            }

            int index = 0;
            chaineString.Reverse();
            List<char> chaineModif = new List<char>();

            foreach (char i in chaineString)
            {
                if (index == 3)
                {
                    chaineModif.Add(' ');
                    index = 0;
                }
                chaineModif.Add(i);

                index++;
            }

            chaineModif.Reverse();
            string ARetourner = string.Empty;

            foreach (char i in chaineModif)
            {
                ARetourner += i;
            }

            /* Liberation de la mémoire */
            chaineString.Clear();
            chaineModif.Clear();
            elementString = string.Empty;

            /* Liberation de la mémoire */
            chaineString = null;
            elementString = null;
            chaineModif = null;

            return ARetourner;
        }

        private void DownloadForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            e.Cancel = true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();

            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini"))
            {
                StreamReader reader = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini");
                byte nbUpdate = Convert.ToByte(reader.ReadLine());
                List<string> App = new List<string>();

                for (byte index = 0; index < nbUpdate; index++)
                {
                    App.Add(reader.ReadLine());
                }
                LibVLCVersion = reader.ReadLine();

                reader.Close();
                this.APP = App;
                File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini");
            }

            if (Directory.Exists(Application.StartupPath + "Install"))
            {
                Directory.Delete(Application.StartupPath + "Install", true);
            }

            Directory.CreateDirectory(Application.StartupPath + "Install");
            nbUpdate++;
            AppDownload(APP[0]);
        }
    }
}
