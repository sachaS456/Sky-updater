﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Principal;
using System.Diagnostics;
using Microsoft.Win32;

namespace Sky_installer
{
    public static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            System.Threading.Thread.Sleep(1500);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (IsElevated() == false)
            {
                using (Process configTool = new Process())
                {
                    configTool.StartInfo.FileName = Application.ExecutablePath;
                    configTool.StartInfo.Verb = "runas";
                    configTool.Start();
                    Environment.Exit(0);
                }
            }

            KillAppSS();

            if (File.Exists(Application.StartupPath + @"\Install\1.zip"))
            {
                if (Directory.Exists(Application.StartupPath + @"\Framework"))
                {
                    Directory.Delete(Application.StartupPath + @"\Framework", true);
                }

                int nbFile = 0;

                foreach (string i in Directory.EnumerateFiles(Application.StartupPath + @"\Install"))
                {
                    if (Convert.ToInt32(Path.GetFileNameWithoutExtension(i)) > nbFile)
                    {
                        nbFile = Convert.ToInt32(Path.GetFileNameWithoutExtension(i));
                    }
                }

                for (int index = 1; index <= nbFile; index++)
                {
                    System.IO.Compression.ZipFile.ExtractToDirectory(Application.StartupPath + @"\Install\" + index + ".zip", Application.StartupPath + @"\Framework");
                }

                //System.IO.Compression.ZipFile.ExtractToDirectory(Application.StartupPath + @"\Framework.zip", Application.StartupPath + @"\Framework");
                //System.IO.File.Delete(Application.StartupPath + @"\Framework.zip");

                foreach (string i in Directory.EnumerateFileSystemEntries(Application.StartupPath + @"\Framework"))
                {
                    if (File.Exists(Application.StartupPath + @"\" + Path.GetFileName(i)))
                    {
                        File.Delete(Application.StartupPath + @"\" + Path.GetFileName(i));
                    }
                    else if (Directory.Exists(Application.StartupPath + @"\" + new DirectoryInfo(i).Name))
                    {
                        Directory.Delete(Application.StartupPath + @"\" + new DirectoryInfo(i).Name, true);
                    }

                    if (Directory.Exists(i))
                    {
                        Directory.Move(i, Application.StartupPath + @"\" + new DirectoryInfo(i).Name);
                    }
                    else if (System.IO.File.Exists(i))
                    {
                        System.IO.File.Move(i, Application.StartupPath + @"\" + Path.GetFileName(i));
                    }
                }

                if (Directory.Exists(Application.StartupPath + @"\Framework"))
                {
                    Directory.Delete(Application.StartupPath + @"\Framework", true);
                }
            }

            if (File.Exists(Application.StartupPath + @"\Install\Sky updater.exe"))
            {
                foreach (string i in Directory.EnumerateFileSystemEntries(Application.StartupPath + @"\Install"))
                {
                    if (File.Exists(Application.StartupPath + @"\" + Path.GetFileName(i)))
                    {
                        File.Delete(Application.StartupPath + @"\" + Path.GetFileName(i));
                    }
                    else if (Directory.Exists(Application.StartupPath + @"\"  + new DirectoryInfo(i).Name))
                    {
                        Directory.Delete(Application.StartupPath + @"\" + new DirectoryInfo(i).Name, true);
                    }

                    if (Directory.Exists(i))
                    {
                        Directory.Move(i, Application.StartupPath + @"\" + new DirectoryInfo(i).Name);
                    }
                    else if (System.IO.File.Exists(i))
                    {
                        System.IO.File.Move(i, Application.StartupPath + @"\" + Path.GetFileName(i));
                    }
                }
            }

            if (Directory.Exists(Application.StartupPath + @"\Install"))
            {
                Directory.Delete(Application.StartupPath + @"\Install", true);  // netoyage
            }

            RegistreConfig();

            MessageBox.Show("La mise à jour est un succès!", "Sky updater", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private static bool IsElevated()
        {
            WindowsIdentity id = WindowsIdentity.GetCurrent();
            return id.Owner != id.User;
        }

        private static void RegistreConfig()
        {
            RegistryKey classesKey = null;

            if (Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky multi 2", false) != null)
            {
                associationFichier("Sky multi", Application.StartupPath + @"\");
            }

            if (Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky picture 2", false) != null)
            {
                associationFichier("Sky picture", Application.StartupPath + @"\");
            }

            if (Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky note 2", false) != null)
            {
                associationFichier("Sky note", Application.StartupPath + @"\");

                classesKey = Registry.ClassesRoot.OpenSubKey(".txt", true);
                classesKey.OpenSubKey(@"Directory\background\shell\", true).DeleteSubKeyTree("Sky note"); // supprime une erreur d'une précedante mise à jour

                classesKey.CreateSubKey("ShellNew").SetValue("ItemName", Application.StartupPath + @"\Sky note.exe");
                classesKey.CreateSubKey("ShellNew").SetValue("NullFile", string.Empty);
                classesKey.CreateSubKey(@"Sky note\command").SetValue(string.Empty, Application.StartupPath + @"\Sky note.exe");
                classesKey.Close();
                classesKey = null;
            }

            /*if (Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky diary 2", false) != null)
            {
                
            }*/

            if (Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Sky encrypt 2", false) != null)
            {
                associationFichier("Sky encrypt", Application.StartupPath + @"\");

                classesKey = Registry.ClassesRoot.OpenSubKey(@"Directory\shell", true);
                classesKey.CreateSubKey(@"Sky encrypt").SetValue(string.Empty, "Chiffrer");
                classesKey.CreateSubKey(@"Sky encrypt").SetValue("Icon", Application.StartupPath + @"\Sky encrypt.ico");
                classesKey.CreateSubKey(@"Sky encrypt\command").SetValue(string.Empty, '"' + Application.StartupPath + @"\Sky encrypt.exe" + '"' + " " + '"' + "%1" + '"');
                classesKey.Close();

                classesKey = Registry.ClassesRoot.OpenSubKey(@"*\shell", true);
                classesKey.CreateSubKey(@"Sky encrypt").SetValue(string.Empty, "Chiffrer ou déchiffrer");
                classesKey.CreateSubKey(@"Sky encrypt").SetValue("Icon", Application.StartupPath + @"\Sky encrypt.ico");
                classesKey.CreateSubKey(@"Sky encrypt\command").SetValue(string.Empty, '"' + Application.StartupPath + @"\Sky encrypt.exe" + '"' + " " + '"' + "%1" + '"');
                classesKey.Close();
                classesKey = null;
            }
        }

        private static void associationFichier(string App, string Emplacement)
        {
            switch (App)
            {
                case "Sky multi":
                    // vidéo :
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mkv", App + ".mkv", "Fichier vidéo mkv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".avi", App + ".avi", "Fichier vidéo avi");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mp4", App + ".mp4", "Fichier vidéo mp4");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".flv", App + ".flv", "Fichier vidéo flv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".m2ts", App + ".m2ts", "Fichier vidéo m2ts");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mov", App + ".mov", "Fichier vidéo mov");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpeg", App + ".mpeg", "Fichier vidéo mprg");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpeg1", App + ".mpeg1", "Fichier vidéo mpeg1");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpeg2", App + ".mpeg2", "Fichier vidéo mpeg2");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mts", App + ".mts", "Fichier vidéo mts");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ogg", App + ".ogg", "Fichier vidéo ogg");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".wmv", App + ".wmv", "Fichier vidéo wmv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".3g2", App + ".3g2", "Fichier vidéo 3g2");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".3gp", App + ".3gp", "Fichier vidéo 3gp");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".3gp2", App + ".3gp2", "Fichier vidéo 3gp2");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".3gpp", App + ".3gpp", "Fichier vidéo 3gpp");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".asf", App + ".asf", "Fichier vidéo asf");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".bik", App + ".bik", "Fichier vidéo bik");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".divx", App + ".divx", "Fichier vidéo divx");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".drc", App + ".drc", "Fichier vidéo drc");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".dv", App + ".dv", "Fichier vidéo dv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".dvr-ms", App + ".dvr-ms", "Fichier vidéo dvr-ms");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".evo", App + ".evo", "Fichier vidéo evo");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".f4v", App + ".f4v", "Fichier vidéo f4v");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".gvi", App + ".gvi", "Fichier vidéo gvi");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".gxv", App + ".gxv", "Fichier vidéo gxv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".m1v", App + ".m1v", "Fichier vidéo m1v");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".m2t", App + ".m2t", "Fichier vidéo m2t");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".m2v", App + ".m2v", "Fichier vidéo m2v");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".m4v", App + ".m4v", "Fichier vidéo m4v");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mp2v", App + ".mp2v", "Fichier vidéo mp2v");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mp4v", App + ".mp4v", "Fichier vidéo mp4v");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpa", App + ".mpa", "Fichier vidéo mpa");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpe", App + ".mpe", "Fichier vidéo mpe");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpeg4", App + ".mpeg4", "Fichier vidéo mpeg4");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpg", App + ".mpg", "Fichier vidéo mpg");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpv2", App + ".mpv2", "Fichier vidéo mpv2");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mtv", App + ".mtv", "Fichier vidéo mtv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mxf", App + ".mxf", "Fichier vidéo mxf");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".nsv", App + ".nsv", "Fichier vidéo nsv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".nuv", App + ".nuv", "Fichier vidéo nuv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ogm", App + ".ogm", "Fichier vidéo ogm");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ogv", App + ".ogv", "Fichier vidéo ogv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ogx", App + ".ogx", "Fichier vidéo ogx");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".rec", App + ".rec", "Fichier vidéo rec");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".rm", App + ".rm", "Fichier vidéo rm");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".rmvb", App + ".rmvb", "Fichier vidéo rmvb");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".rpl", App + ".rpl", "Fichier vidéo rpl");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".thp", App + ".thp", "Fichier vidéo thp");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".tod", App + ".tod", "Fichier vidéo tod");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".tp", App + ".tp", "Fichier vidéo tp");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ts", App + ".ts", "Fichier vidéo ts");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".tts", App + ".tts", "Fichier vidéo tts");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".vob", App + ".vob", "Fichier vidéo vob");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".vro", App + ".vro", "Fichier vidéo vro");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".webm", App + ".webm", "Fichier vidéo webm");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".wtv", App + ".wtv", "Fichier vidéo wtv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".xesc", App + ".xesc", "Fichier vidéo xesc");

                    // audio :
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".m4a", App + ".m4a", "Fichier audio m4a");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mp3", App + ".mp3", "Fichier audio mp3");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".wav", App + ".wav", "Fichier audio wav");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".wma", App + ".wma", "Fichier audio wma");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".3ga", App + ".3ga", "Fichier audio 3ga");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".669", App + ".669", "Fichier audio 669");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".a52", App + ".a52", "Fichier audio a52");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".aac", App + ".aac", "Fichier audio aac");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ac3", App + ".ac3", "Fichier audio ac3");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".adt", App + ".adt", "Fichier audio adt");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".adts", App + ".adts", "Fichier audio adts");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".aif", App + ".aif", "Fichier audio aif");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".aifc", App + ".aifc", "Fichier audio aifc");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".aiff", App + ".aiff", "Fichier audio aiff");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".amr", App + ".amr", "Fichier audio amr");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".aob", App + ".aob", "Fichier audio aob");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ape", App + ".ape", "Fichier audio ape");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".au", App + ".au", "Fichier audio au");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".caf", App + ".caf", "Fichier audio caf");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".cda", App + ".cda", "Fichier audio cda");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".dts", App + ".dts", "Fichier audio dts");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".flac", App + ".flac", "Fichier audio flac");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".it", App + ".it", "Fichier audio it");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".m4p", App + ".m4p", "Fichier audio m4p");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mid", App + ".mid", "Fichier audio mid");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mka", App + ".mka", "Fichier audio mka");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mlp", App + ".mlp", "Fichier audio mlp");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mod", App + ".mod", "Fichier audio mod");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mp1", App + ".mp1", "Fichier audio mp1");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mp2", App + ".mp2", "Fichier audio mp2");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpc", App + ".mpc", "Fichier audio mpc");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".mpga", App + ".mpga", "Fichier audio mpga");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".oga", App + ".oga", "Fichier audio oga");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".oma", App + ".oma", "Fichier audio oma");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".opus", App + ".opus", "Fichier audio opus");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".qcp", App + ".qcp", "Fichier audio qcp");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ra", App + ".ra", "Fichier audio ra");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".rmi", App + ".rmi", "Fichier audio rmi");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".s3m", App + ".s3m", "Fichier audio s3m");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".snd", App + ".snd", "Fichier audio snd");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".spx", App + ".spx", "Fichier audio spx");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".tta", App + ".tta", "Fichier audio tta");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".voc", App + ".voc", "Fichier audio voc");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".vqf", App + ".vqf", "Fichier audio vqf");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".w64", App + ".w64", "Fichier audio w64");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".wv", App + ".wv", "Fichier audio wv");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".xa", App + ".xa", "Fichier audio xa");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".xm", App + ".xm", "Fichier audio xm");

                    break;

                case "Sky picture":
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".png", App + ".png", "Fichier image png");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".jpg", App + ".jpg", "Fichier image jpg");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".gif", App + ".gif", "Fichier image gif");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ico", App + ".ico", "Fichier image ico");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".tiff", App + ".tiff", "Fichier image tiff");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".jpeg", App + ".jpeg", "Fichier image jpeg");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".bmp", App + ".bmp", "Fichier image bmp");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".raw", App + ".raw", "Fichier image raw");
                    break;

                case "Sky note":
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".txt", App + ".txt", "Fichier texte");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".bat", App + ".bat", "Fichier de commande windows");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".log", App + ".log", "Fichier log");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".html", App + ".html", "Fichier html");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ini", App + ".ini", "Fichier de configuration");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".xml", App + ".xml", "Fichier xml");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".dat", App + ".dat", "Fichier dat");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".asar", App + ".asar", "Fichier asar");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".psd1", App + ".psd1", "Fichier de données Windows PowerShell");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".psm1", App + ".psm1", "Fichier de Module de script Windows PowerShell");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ps1", App + ".ps1", "Fichier de script Windows PowerShell");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".plist", App + ".plist", "Fichier plist");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".yml", App + ".yml", "Fichier yml");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".old", App + ".old", "Fichier old");
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".bin", App + ".bin", "Fichier bin");
                    break;

                case "Sky diary":
                    // aucune association de fichier à faire pour le moment.
                    break;

                case "Sky encrypt":
                    SetFileAssociation(Emplacement + App + ".ico", Emplacement + App, ".ss2se", App + ".ss2se", "Fichier Chiffrée par Sky encrypt");
                    break;
            }
        }

        private static void SetFileAssociation(string icon, string application, string extension, string progId, string description)
        {
            RegistryKey classesKey = Registry.CurrentUser.OpenSubKey(@"Software\Classes", true);
            classesKey.CreateSubKey(extension).SetValue(string.Empty, progId);
            RegistryKey progKey = classesKey.CreateSubKey(progId);

            if (description != null && description != string.Empty)
            {
                progKey.SetValue(string.Empty, description);
            }

            if (icon != null && icon != string.Empty)
            {
                progKey.CreateSubKey("DefaultIcon").SetValue(string.Empty, icon);
            }

            progKey.CreateSubKey(@"Shell\Open\Command").SetValue(string.Empty, '"' + application + ".exe" + '"' + " " + '"' + "%1" + '"');
        }

        private static void KillAppSS()
        {
            try
            {
                Process[] app = Process.GetProcesses();

                foreach (Process myProcess in app)
                {
                    switch (myProcess.ProcessName)
                    {
                        case "Sky multi":
                            myProcess.Kill();
                            break;

                        case "Sky picture":
                            myProcess.Kill();
                            break;

                        case "Sky note":
                            myProcess.Kill();
                            break;

                        case "Sky diary":
                            myProcess.Kill();
                            break;

                        case "Sky encrypt":
                            myProcess.Kill();
                            break;

                        case "Sky updater":
                            myProcess.Kill();
                            break;
                    }

                    myProcess.Dispose();
                }

                app = null;
            }
            catch
            {
                // error
            }
        }
    }
}
