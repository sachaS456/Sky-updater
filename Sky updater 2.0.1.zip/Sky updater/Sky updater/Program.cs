using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Sky_updater
{
    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky\Update.ini"))
            {
                Application.Run(new DownloadForm());
            }
            else if (Directory.Exists(Application.StartupPath + "Install"))
            {
                Directory.Delete(Application.StartupPath + "Install", true);
            }
        }
    }
}
