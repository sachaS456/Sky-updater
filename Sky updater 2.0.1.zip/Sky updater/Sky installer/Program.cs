﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Principal;
using System.Diagnostics;

namespace Sky_installer
{
    public static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (IsElevated() == false)
            {
                using (Process configTool = new Process())
                {
                    configTool.StartInfo.FileName = Application.ExecutablePath;
                    configTool.StartInfo.Verb = "runas";
                    configTool.Start();
                    Environment.Exit(0);
                }
            }

            if (File.Exists(Application.StartupPath + @"\Framework.zip"))
            {
                if (Directory.Exists(Application.StartupPath + @"\Framework"))
                {
                    Directory.Delete(Application.StartupPath + @"\Framework", true);
                }

                System.IO.Compression.ZipFile.ExtractToDirectory(Application.StartupPath + @"\Framework.zip", Application.StartupPath + @"\Framework");
                System.IO.File.Delete(Application.StartupPath + @"\Framework.zip");

                foreach (string i in Directory.EnumerateFileSystemEntries(Application.StartupPath + @"\Framework"))
                {
                    if (File.Exists(Application.StartupPath + @"\" + Path.GetFileName(i)))
                    {
                        File.Delete(Application.StartupPath + @"\" + Path.GetFileName(i));
                    }
                    else if (Directory.Exists(Application.StartupPath + @"\" + new DirectoryInfo(i).Name))
                    {
                        Directory.Delete(Application.StartupPath + @"\" + new DirectoryInfo(i).Name, true);
                    }

                    if (Directory.Exists(i))
                    {
                        Directory.Move(i, Application.StartupPath + @"\" + new DirectoryInfo(i).Name);
                    }
                    else if (System.IO.File.Exists(i))
                    {
                        System.IO.File.Move(i, Application.StartupPath + @"\" + Path.GetFileName(i));
                    }
                }

                if (Directory.Exists(Application.StartupPath + @"\Framework"))
                {
                    Directory.Delete(Application.StartupPath + @"\Framework", true);
                }
            }

            if (File.Exists(Application.StartupPath + @"\Install\Sky updater.exe"))
            {
                foreach (string i in Directory.EnumerateFileSystemEntries(Application.StartupPath + @"\Install"))
                {
                    if (File.Exists(Application.StartupPath + @"\" + Path.GetFileName(i)))
                    {
                        File.Delete(Application.StartupPath + @"\" + Path.GetFileName(i));
                    }
                    else if (Directory.Exists(Application.StartupPath + @"\"  + new DirectoryInfo(i).Name))
                    {
                        Directory.Delete(Application.StartupPath + @"\" + new DirectoryInfo(i).Name, true);
                    }

                    if (Directory.Exists(i))
                    {
                        Directory.Move(i, Application.StartupPath + @"\" + new DirectoryInfo(i).Name);
                    }
                    else if (System.IO.File.Exists(i))
                    {
                        System.IO.File.Move(i, Application.StartupPath + @"\" + Path.GetFileName(i));
                    }
                }
            }
        }

        private static bool IsElevated()
        {
            WindowsIdentity id = WindowsIdentity.GetCurrent();
            return id.Owner != id.User;
        }
    }
}
