﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Sky_updater
{
    internal partial class TwoUpdateForm : Form
    {
        private bool FormCache = false;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private string LibVLCVersion;

        internal TwoUpdateForm(string AppName1, string AppVersion1, string LastVersionApp1, string AppName2, string AppVersion2, string LastVersionApp2, ref string LibVLCVersionc)
        {
            InitializeComponent();

            this.Opacity = 0;
            timer1.Enabled = true;

            label6.Text = AppName1;
            label2.Text += "\n" + AppVersion1;
            label3.Text += "\n" + LastVersionApp1;

            label7.Text = AppName2;
            label11.Text += "\n" + AppVersion2;
            label10.Text += "\n" + LastVersionApp2;

            LibVLCVersion = LibVLCVersionc;

            switch (Application.ProductName)
            {
                case "Sky multi":
                    //panel3.BackColor = Color.FromArgb(255, 128, 0);
                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "sans__yYG_icon.ico");
                    break;

                case "Sky picture":

                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "loga_sky_picture_rjO_icon.ico");
                    break;

                case "Sky note":

                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "sans_titre_RgF_icon.ico");
                    break;

                case "Sky diary":
                    //panel3.BackColor = Color.Maroon;
                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "sky_diary_kd9_icon.ico");
                    break;

                case "Sky encrypt":
                    //panel3.BackColor = Color.Green;
                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "sky_encrypt_wux_icon.ico");
                    break;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    this.Close();
                }
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                FormDeplace = false;
            }
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini"))
            {
                File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini");
            }
            StreamWriter writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini");
            writer.Write("2\n" + label6.Text + "\n" + label7.Text + "\n" + LibVLCVersion);
            writer.Close();

            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.FileName = Application.StartupPath + "Sky updater.exe";
            process.Start();
            process.Close();
            process = null;
            Environment.Exit(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void TwoUpdateForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            if (this.Opacity == 1)
            {
                e.Cancel = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.LinkVisited = true;
            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            if (label6.Text == "Framework")
            {
                process.StartInfo.FileName = "https://github.com/dotnet/core/tree/master/release-notes/";
            }
            else
            {
                process.StartInfo.FileName = "https://serie-sky.netlify.app/Release-note-" + label6.Text + ".html";
            }
            process.Start();
            process.Close();
            process = null;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel2.LinkVisited = true;
            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            if (label7.Text == "Framework")
            {
                process.StartInfo.FileName = "https://github.com/dotnet/core/tree/master/release-notes/";
            }
            else
            {
                process.StartInfo.FileName = "https://serie-sky.netlify.app/Release-note-" + label7.Text + ".html";
            }
            process.Start();
            process.Close();
            process = null;
        }
    }
}
