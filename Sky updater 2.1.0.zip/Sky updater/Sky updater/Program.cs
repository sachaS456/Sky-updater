using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Sky_updater
{
    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\S�rie Sky\Update.ini"))
            {
                MessageBox.Show("Attention les logiciels de la S�rie Sky (Sky multi, Sky picture, Sky note, Sky diary ou Sky encrypt) vont se fermer!", "Sky updater", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Update.KillAppSS();

                Application.Run(new DownloadForm());
            }
        }
    }
}
