﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Sky_updater
{
    internal partial class OneUpdateForm : Form
    {
        private bool FormCache = false;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private string LibVLCVersion;
        private string LastVersionFramework;

        internal OneUpdateForm(string AppName1, string AppVersion1, string LastVersionApp1, ref string LibVLCVersionc)
        {
            InitializeComponent();

            this.Opacity = 0;
            timer1.Enabled = true;

            label6.Text = AppName1;
            label3.Text += "\n" + LastVersionApp1;
            label2.Text += "\n" + AppVersion1;
            if (AppName1 == "Framework")
            {
                LastVersionFramework = LastVersionApp1;
            }

            LibVLCVersion = LibVLCVersionc;

            label6.Location = new Point(panel3.Size.Width / 2 - (label6.Size.Width / 2), label6.Location.Y);

            switch (Application.ProductName)
            {
                case "Sky multi":
                    //panel3.BackColor = Color.FromArgb(255, 128, 0);
                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "Sky multi.ico");
                    break;

                case "Sky picture":

                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "Sky picture.ico");
                    break;

                case "Sky note":

                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "Sky note.ico");
                    break;

                case "Sky diary":
                    //panel3.BackColor = Color.Maroon;
                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "Sky diary.ico");
                    break;

                case "Sky encrypt":
                    //panel3.BackColor = Color.Green;
                    this.Icon = Icon.ExtractAssociatedIcon(Application.StartupPath + "Sky encrypt.ico");
                    break;
            }
        }              

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    this.Close();
                }
            }
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
            }
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                FormDeplace = false;
            }
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini"))
            {
                File.Delete(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini");
            }
            StreamWriter writer = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Série Sky\Update.ini");
            writer.Write("1\n" + label6.Text + "\n" + LibVLCVersion);
            writer.Close();

            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.FileName = Application.StartupPath + "Sky updater.exe";
            process.Start();
            process.Close();
            process = null;
            Environment.Exit(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void OneUpdateForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            if (this.Opacity == 1)
            {
                e.Cancel = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.LinkVisited = true;
            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            if (label6.Text == "Framework")
            {
                process.StartInfo.FileName = "https://github.com/dotnet/core/blob/main/release-notes/" + LastVersionFramework[0] + LastVersionFramework[1] + LastVersionFramework[2] + "/" +
                    LastVersionFramework + "/" + LastVersionFramework + ".md";
            }
            else
            {
                process.StartInfo.FileName = "https://serie-sky.netlify.app/Release-note-" + label6.Text + ".html";
            }
            process.Start();
            process.Close();
            process = null;
        }
    }
}
