﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Reflection;
using System.Diagnostics;

namespace Sky_updater
{
    public static class Update
    {
        public static void CheckUpdate(string AppName, string AppVersion, string LibVLCVersion = "")
        {
            DataUpdate dataUpdate = CheckVersion(ref AppName, ref AppVersion);

            switch (dataUpdate.AppName.Count())
            {
                case 1:
                    new OneUpdateForm(dataUpdate.AppName[0], dataUpdate.Version[0], dataUpdate.LastVersion[0], ref LibVLCVersion).ShowDialog();
                    break;

                case 2:
                    new TwoUpdateForm(dataUpdate.AppName[0], dataUpdate.Version[0], dataUpdate.LastVersion[0], dataUpdate.AppName[1], dataUpdate.Version[1], dataUpdate.LastVersion[1], ref LibVLCVersion).ShowDialog();
                    break;

                case 3:
                    new TreeUpdateForm(dataUpdate.AppName[0], dataUpdate.Version[0], dataUpdate.LastVersion[0], dataUpdate.AppName[1], dataUpdate.Version[1], dataUpdate.LastVersion[1], dataUpdate.AppName[2], dataUpdate.Version[2], dataUpdate.LastVersion[2], ref LibVLCVersion).ShowDialog();
                    break;
            }

            dataUpdate.Dispose();
            dataUpdate = null;
        }

        internal static void KillAppSS()
        {
            Process[] app = Process.GetProcesses();

            foreach (Process myProcess in app)
            {
                switch (myProcess.ProcessName)
                {
                    case "Sky multi":
                        myProcess.Kill();
                        break;

                    case "Sky picture":
                        myProcess.Kill();
                        break;

                    case "Sky note":
                        myProcess.Kill();
                        break;

                    case "Sky diary":
                        myProcess.Kill();
                        break;

                    case "Sky encrypt":
                        myProcess.Kill();
                        break;
                }

                myProcess.Dispose();
            }

            app = null;
        }

        internal static bool CheckLibVLC(ref string LibVLCVersion)
        {
            if (LibVLCVersion == string.Empty || LibVLCVersion == null)
            {
                return false;
            }

            WebClient client = new WebClient();

            StreamReader reader1 = new StreamReader(client.OpenRead("https://serie-sky.netlify.app/Download/Sky multi r.ini"));
            reader1.ReadLine();
            string Version1 = reader1.ReadLine();

            reader1.Close();
            client.Dispose();
            client = null;

            if (Version1 != LibVLCVersion)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static DataUpdate CheckVersion(ref string AppName, ref string AppVersion)
        {
            DataUpdate App = new DataUpdate();

            using (WebClient client = new WebClient())
            {

                StreamReader reader;
                string Version;

                // Check Framework
                try
                {
                    reader = new StreamReader(client.OpenRead("https://serie-sky.netlify.app/Download/Framework Net r.ini"));
                    Version = reader.ReadToEnd();
                    reader.Close();

                    if (File.Exists(Application.StartupPath + "Framework r.ini"))
                    {
                        StreamReader reader1 = new StreamReader(Application.StartupPath + "Framework r.ini");
                        string LocalVersion = reader1.ReadToEnd();
                        reader1.Close();

                        if (Version != LocalVersion)
                        {
                            App.AppName.Add("Framework");
                            App.Version.Add(LocalVersion);
                            App.LastVersion.Add(Version);
                        }
                    }
                    else
                    {
                        App.AppName.Add("Framework");
                        App.Version.Add("Error");
                        App.LastVersion.Add(Version);
                    }
                }
                catch
                {
                    AppName = null;
                    AppVersion = null;
                    Version = null;
                    client.Dispose();

                    return App;  // connection is lost
                }

                // Check Sky Updater
                reader = new StreamReader(client.OpenRead("https://serie-sky.netlify.app/Download/Sky updater r.ini"));
                Version = reader.ReadToEnd();
                reader.Close();
                if (Version != AssemblyName.GetAssemblyName(Application.StartupPath + "Sky updater.dll").Version.ToString())
                {
                    App.AppName.Add("Sky updater");
                    App.Version.Add(AssemblyName.GetAssemblyName(Application.StartupPath + "Sky updater.dll").Version.ToString());
                    App.LastVersion.Add(Version);
                }

                Version = null;
                reader = null;

                // Check App selected
                switch (AppName)
                {
                    case "Sky multi":

                        StreamReader reader1 = new StreamReader(client.OpenRead("https://serie-sky.netlify.app/Download/Sky multi r.ini"));
                        string Version1 = reader1.ReadLine();
                        reader1.Close();
                        reader1 = null;
                        if (Version1 != AppVersion)
                        {
                            App.AppName.Add(AppName);
                            App.Version.Add(AppVersion);
                            App.LastVersion.Add(Version1);

                            AppName = null;
                            AppVersion = null;
                            Version1 = null;
                            client.Dispose();
                            return App;
                        }
                        AppName = null;
                        AppVersion = null;
                        Version1 = null;
                        client.Dispose();
                        break;

                    case "Sky picture":

                        StreamReader reader2 = new StreamReader(client.OpenRead("https://serie-sky.netlify.app/Download/Sky picture r.ini"));
                        string Version2 = reader2.ReadToEnd();
                        reader2.Close();
                        reader2 = null;
                        if (Version2 != AppVersion)
                        {
                            App.AppName.Add(AppName);
                            App.Version.Add(AppVersion);
                            App.LastVersion.Add(Version2);

                            AppName = null;
                            AppVersion = null;
                            Version2 = null;
                            client.Dispose();
                            return App;
                        }
                        AppName = null;
                        AppVersion = null;
                        Version2 = null;
                        client.Dispose();
                        break;

                    case "Sky note":

                        StreamReader reader3 = new StreamReader(client.OpenRead("https://serie-sky.netlify.app/Download/Sky note r.ini"));
                        string Version3 = reader3.ReadToEnd();
                        reader3.Close();
                        reader3 = null;
                        if (Version3 != AppVersion)
                        {
                            App.AppName.Add(AppName);
                            App.Version.Add(AppVersion);
                            App.LastVersion.Add(Version3);

                            AppName = null;
                            AppVersion = null;
                            Version3 = null;
                            client.Dispose();
                            return App;
                        }
                        AppName = null;
                        AppVersion = null;
                        Version3 = null;
                        client.Dispose();
                        break;

                    case "Sky diary":

                        StreamReader reader4 = new StreamReader(client.OpenRead("https://serie-sky.netlify.app/Download/Sky diary r.ini"));
                        string Version4 = reader4.ReadToEnd();
                        reader4.Close();
                        reader4 = null;
                        if (Version4 != AppVersion)
                        {
                            App.AppName.Add(AppName);
                            App.Version.Add(AppVersion);
                            App.LastVersion.Add(Version4);

                            AppName = null;
                            AppVersion = null;
                            Version4 = null;
                            client.Dispose();
                            return App;
                        }
                        AppName = null;
                        AppVersion = null;
                        Version4 = null;
                        client.Dispose();
                        break;

                    case "Sky encrypt":

                        StreamReader reader5 = new StreamReader(client.OpenRead("https://serie-sky.netlify.app/Download/Sky encrypt r.ini"));
                        string Version5 = reader5.ReadToEnd();
                        reader5.Close();
                        reader5 = null;
                        if (Version5 != AppVersion)
                        {
                            App.AppName.Add(AppName);
                            App.Version.Add(AppVersion);
                            App.LastVersion.Add(Version5);

                            AppName = null;
                            AppVersion = null;
                            Version5 = null;
                            client.Dispose();
                            return App;
                        }
                        AppName = null;
                        AppVersion = null;
                        Version5 = null;
                        client.Dispose();
                        break;
                }
                client.Dispose();
                AppName = null;
                AppVersion = null;
            }

            return App;
        }
    }

    internal class DataUpdate
    {
        internal List<string> Version = new List<string>();
        internal List<string> LastVersion = new List<string>();
        internal List<string> AppName = new List<string>();

        internal void Dispose()
        {                       
            Version.Clear();
            LastVersion.Clear();
            AppName.Clear();

            Version = null;
            LastVersion = null;
            AppName = null;
        }
    }
}
